Welcome to the Infinity.... 
<*)))))><
<*)))))><
<*)))))>< 
INFO[2021-11-26T09:28:34+08:00] version: 0.5.3-dev                           
WARN[2021-11-26T09:28:34+08:00] clef is not enabled; portability and security of your keys is sub optimal 
INFO[2021-11-26T09:28:34+08:00] using existing infinity network address: 2b7933223dceb8ebcc0f0023f22ae2e922f84d5dd66321b187de0c103dd94453 
INFO[2021-11-26T09:28:34+08:00] infinity public key 021d9e61480e42621ccc3fce4da7d35051f41707e75b21cc1c908da3404c7b0392 
INFO[2021-11-26T09:28:34+08:00] pss public key 0388476827c23b00ec9af8c7ca53f4006ee04d2972f1cc5b7bc04bb32df46f3010 
INFO[2021-11-26T09:28:34+08:00] using infinity address 4e6da3d9526340a81876533d16a6e136d82eec71 
INFO[2021-11-26T09:28:34+08:00] debug api address: [::]:1635                 
INFO[2021-11-26T09:28:35+08:00] using custom factory address: ac61e8f921b10452dbfaa66ac833d3a522e61290 
INFO[2021-11-26T09:28:35+08:00] using existing chequebook 5a78d561d4bf07bab2501fe2c8b34249f2b52c4f 
File not found.

2021/11/26 09:28:36 failed to sufficiently increase receive buffer size (was: 208 kiB, wanted: 2048 kiB, got: 416 kiB). See https://github.com/lucas-clemente/quic-go/wiki/UDP-Receive-Buffer-Size for details.
WARN[2021-11-26T09:28:49+08:00] invalid bootnode address /18.183.82.121/p2p/16Uiu2HAmT2rcJJfaAyjFyLQecosEmCyAmSUWoEZBceig3rQmTP4v 
INFO[2021-11-26T09:28:49+08:00] database capacity: 5000000 chunks (approximately 19.5GB) 
INFO[2021-11-26T09:28:49+08:00] name resolver: no name resolution service provided 
INFO[2021-11-26T09:28:49+08:00] api address: [::]:1633                       
compute cpu reward according to the following cpu information:4e6da3d9526340a81876533d16a6e136d82eec71
Name: Intel(R) Xeon(R) CPU E5-2686 v4 @ 2.30GHz
PhysicalCores: 2
ThreadsPerCore: 1
LogicalCores: 2
Family 6 Model: 79
Features: CMOV,NX,MMX,MMXEXT,SSE,SSE2,SSE3,SSSE3,SSE4.1,SSE4.2,AVX,AVX2,FMA3,F16C,BMI1,BMI2,LZCNT,POPCNT,AESNI,CLMUL,RDRAND,ERMS,RDTSCP,CX16
Cacheline bytes: 64
L1 Data Cache: 32768 bytes
L1 Instruction Cache: 32768 bytes
L2 Cache: 262144 bytes
L3 Cache: 47185920 bytes
We have Streaming SIMD Extensions
The score of CPU is: 18d19800
File not found.





compute cpu reward according to the following cpu information:4e6da3d9526340a81876533d16a6e136d82eec71
Name: Intel(R) Xeon(R) CPU E5-2686 v4 @ 2.30GHz
PhysicalCores: 2
ThreadsPerCore: 1
LogicalCores: 2
Family 6 Model: 79
Features: CMOV,NX,MMX,MMXEXT,SSE,SSE2,SSE3,SSSE3,SSE4.1,SSE4.2,AVX,AVX2,FMA3,F16C,BMI1,BMI2,LZCNT,POPCNT,AESNI,CLMUL,RDRAND,ERMS,RDTSCP,CX16
Cacheline bytes: 64
L1 Data Cache: 32768 bytes
L1 Instruction Cache: 32768 bytes
L2 Cache: 262144 bytes
L3 Cache: 47185920 bytes
We have Streaming SIMD Extensions
The score of CPU is: 18d19800
File not found.
